import java.io.*;

class Testpde {

    public static void main (String args[])
    {
	final int m = 72;

	float[][] u    = new float[m+2][m+2];
	float[][] unew = new float[m+2][m+2];

	float h = (float) 1.0/(m+1);
	int i,j;

	// Zero the arrays to start with
	
	for(i=0;i<m+2;i++)
	    {
		for(j=0;j<m+2;j++)
		    {
			unew[i][j]=0;
			u[i][j]=0;
		    }
	    }

	// Read in u from file

	readinputdata(u,m);

	// First impose boundary conditions: set edges of u to zero

        // ** insert appropriate code here **
	

	//                                                _2
	//  Now calculate unew according to PDE: unew = - V u
	//  Note that we ignore any factors of 'h' in this calculation
	//

        //  Just copy input to output for the moment

	for(i=0;i<m+2;i++)
	    {
		for(j=0;j<m+2;j++)
		    {
			unew[i][j]=u[i][j];
		    }
	    }

	//                         _2
	// Then calculate unew = - V u
        //

        // ** insert appropriate code here **


	// Write data to file for visualisation with OpenDX

	dxwrite(unew,m,h);
    }


    public static void readinputdata(float[][] u,int m){

	int i,j;

	System.out.println("readinputdata: reading input data ...");

	if(m!=72)
	    {
		System.out.println("readinputdata: invalid value of m = "
				   + m + ": must have m = 72\n");
		System.out.println("readinputdata: exiting");
		System.exit(1);
	    }

	try
	    {
		String infilename="testpde.dat";
		FileReader infile=new FileReader(infilename);
		BufferedReader reader=new BufferedReader(infile);
	    	    
		for(j=0;j<m+2;j++)
		    {
			for(i=0;i<m+2;i++)
			    {
				u[i][j]=Float.parseFloat(reader.readLine());
			    }
		    }
	    
	    }
	catch(Exception e)
	    {
		System.err.println ("readinputdata: error reading from file");
	    }
	
	System.out.println("readinputdata: ... done");

    }// end readinputdata


    public static void dxwrite(float[][] unew, int m, float h)
    {
	String outfilename="pollution.dat";
	System.out.println("dxwrite: writing "+m+" x "+m+" file to "+outfilename+" with h = "+h);
	
	try
	    {
		FileOutputStream outfile=new FileOutputStream(outfilename);
		PrintStream p = new PrintStream(outfile);

		for(int i=0;i<m+2;i++)
		    {
			for(int j=0;j<m+2;j++)
			    {
				p.println(unew[i][j]);
			    }
		    }
	    }
	catch (Exception e)
	    {
		System.err.println ("Error writing to file");
	    }
	

	String fldfilename="pollution.general";
	System.out.println("dxwrite: writing associated field file to " +  fldfilename);

	try
	    {
		FileOutputStream fldfile=new FileOutputStream(fldfilename);
		PrintStream p = new PrintStream(fldfile);
	
                p.println("file = " +outfilename);
                p.println("grid = " +(m+2) + " x " + (m+2));
                p.println("format = ascii");
                p.println("interleaving = record");
                p.println("majority = row");
                p.println("field = field0");
                p.println("structure = scalar");
                p.println("type = float");
                p.println("dependency = positions");
                p.println("positions = regular, regular, 0, 1, 0, 1");
                p.println("");
                p.println("end");


	    }
	catch(Exception e)
	    {
		System.err.println ("Error writing to file");
	    }
	System.out.println("dxwrite: finished");
    }
}
