#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* Set problem size */

#define M 72

/* Function prototypes */

void dxwrite (float u[M+2][M+2], float h);
void readinputdata(float u[M+2][M+2]);

int main(void)
{
  float u[M+2][M+2];
  float unew[M+2][M+2];

  const float h=1.0/(M+1);

  int i,j;

  /* zero the arrays */

  for(i=0;i<M+2;i++)
    {
      for(j=0;j<M+2;j++)
	{
          u[i][j]    = 0.0;
          unew[i][j] = 0.0;
        }
    }

  /* read in u from file */

  readinputdata(u);

  /* First impose boundary conditions: set edges to zero */

  /** insert appropriate code here **/


  /*                                                _2
   *  Now calculate unew according to PDE: unew = - V u
   *  Note that we ignore any factors of 'h' in this calculation
   */

  /* Just copy input to output for the moment */

  for(i=0;i<M+2;i++)
    {
      for(j=0;j<M+2;j++)
	{
	  unew[i][j]=u[i][j];
	}
    }

  /*                     _2
   *  Calculate unew = - V u
   */

  /** insert appropriate code here **/


  /*
   *  Write data to file for visualisation with OpenDX
   */

  dxwrite(unew,h);
}

void dxwrite(float unew[M+2][M+2],float h)
{
  int i,j;

  char fileroot[32]="pollution";
  char filename[32];
  char fldname [32];
  
  FILE* outfile;

  /* Append suffices to the fileroot */

  sprintf(filename,"%s.dat",fileroot);
  sprintf(fldname, "%s.general",fileroot);

  printf("dxwrite: writing %d x %d file to %s with h = %f\n",
          M,M,filename,h);

  outfile=fopen(filename,"w");

  for(i=0;i<M+2;i++)
   {
      for(j=0;j<M+2;j++)
        {
	  fprintf(outfile,"%f\n",unew[i][j]);
	}
    }
  
  fclose(outfile);
  outfile=fopen(fldname,"w");
  
  printf("dxwrite: writing associated field file to %s\n", fldname);

  fprintf(outfile, "file = %s\n", filename);
  fprintf(outfile, "grid = %d x %d\n", M+2, M+2);
  fprintf(outfile, "format = ascii\n");
  fprintf(outfile, "interleaving = record\n");
  fprintf(outfile, "majority = row\n");
  fprintf(outfile, "field = field0\n");
  fprintf(outfile, "structure = scalar\n");
  fprintf(outfile, "type = float\n");
  fprintf(outfile, "dependency = positions\n");
  fprintf(outfile, "positions = regular, regular, 0, 1, 0, 1\n");
  fprintf(outfile, "\n");
  fprintf(outfile, "end\n");

  fclose(outfile);

  printf("dxwrite: finished\n");
}

void readinputdata(float u[M+2][M+2])
{
  FILE* infile;
  int i,j;

  printf("readinputdata: reading input data ...\n");

  if(M!=72)
  {
    printf("readinputdata: invalid value of M = %d: must have M = 72\n", M);
    printf("readinputdata: exiting\n");
    exit(1);
  }

  infile=fopen("testpde.dat","r");

  for(j=0;j<M+2;j++)
    {
      for(i=0;i<M+2;i++)
      {
      fscanf(infile,"%f", &(u[i][j]));
    }
  }

  fclose(infile);

  printf("readinputdata: ... done\n");
}

